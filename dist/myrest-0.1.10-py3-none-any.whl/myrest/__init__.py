VERSION = (0, 1, 0)
name = "myrest"
__all__ = ['myparser', 'myrestengine']
