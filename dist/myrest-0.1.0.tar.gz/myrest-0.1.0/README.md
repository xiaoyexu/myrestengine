# My Rest Engine
The project is based on django framework, check [Django project](http://www.djangoproject.com) for details


